package snake;

public class ExtendingBait {

}
